<?php include('header.php'); ?>
<!-- on inclut le header -->

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="./cgv.css" />
</head>

<body>
    <div class="content">
        <img src="./image/cgv.jpg" alt="conditions générale de ventes" class="imgcgv" />
        <br /><br />
        <div class="conditionsvente">
            <h2>Clause n° 1 : Objet</h2>
            <p>Les conditions générales de vente décrites ci-après détaillent les droits et obligations de la société BDE CESI et de son client dans le cadre de la vente des marchandises suivantes : ...<br />
                Toute prestation accomplie par la société BDE CESI implique donc l'adhésion sans réserve de l'acheteur aux présentes conditions générales de vente.</p>
            <br />
            <h2>Clause n° 2 : Prix</h2>
            <p>Les prix des marchandises vendues sont ceux en vigueur au jour de la prise de commande.
                Ils sont libellés en euros et calculés hors taxes. Par voie de conséquence, ils seront majorés du taux de TVA et des frais de transport applicables au jour de la commande.
                La société BDE CESI s'accorde le droit de modifier ses tarifs à tout moment.
                Toutefois, elle s'engage à facturer les marchandises commandées aux prix indiqués lors de l'enregistrement de la commande.
            </p>
            <br />
            <h2>Clause n° 3 : Rabais et ristournes</h2>
            <p>Les tarifs proposés comprennent les rabais et ristournes que la société BDE CESI
                serait amenée à octroyer compte tenu de ses résultats ou de la prise en charge par l'acheteur de certaines prestations.
            </p>
            <br />
            <h2>Clause n° 4 : Escompte</h2>
            <p>Aucun escompte ne sera consenti en cas de paiement anticipé.</p>
            <br />
            <h2>Clause n° 5 : Modalités de paiement</h2>
            <p>Le règlement des commandes s'effectue :<br />
                <span class="marge">-soit par chèque ;</span><br />
                <span class="marge">-soit par carte bancaire ;</span><br />
                <span class="marge">-le cas échéant, indiquer les autres moyens de paiement acceptés.</span><br />
                Lors de l'enregistrement de la commande, l'acheteur devra verser un acompte de 10% du montant global de la facture, le solde devant être payé à réception des marchandises.
            </p>
            <br />
            <h2>Clause n° 6 : Retard de paiement</h2>
            <p>En cas de défaut de paiement total ou partiel des marchandises livrées au jour de la réception,
                l'acheteur doit verser à la société BDE CESI une pénalité de retard égale à trois fois le taux de l'intérêt légal.
                Le taux de l'intérêt légal retenu est celui en vigueur au jour de la livraison des marchandises.
            </p>
            <p>Cette pénalité est calculée sur le montant TTC de la somme restant due,
                et court à compter de la date d'échéance du prix sans qu'aucune mise en demeure préalable ne soit nécessaire.
                En sus des indemnités de retard, toute somme, y compris l’acompte,
                non payée à sa date d’exigibilité produira de plein droit le paiement d’une indemnité forfaitaire de 40 euros due au titre des frais de recouvrement.
            </p>
            <br />
            <h2>Clause n° 7 : Clause résolutoire</h2>
            <p>Si dans les quinze jours qui suivent la mise en oeuvre de la clause " Retard de paiement ",
                l'acheteur ne s'est pas acquitté des sommes restant dues,
                la vente sera résolue de plein droit et pourra ouvrir droit à l'allocation de dommages et intérêts au profit de la société BDE CESI.
            </p>
            <br />
            <h2>Clause n° 8 : Clause de réserve de propriété</h2>
            <p>La société BDE CESI conserve la propriété des biens vendus jusqu'au paiement intégral du prix,
                en principal et en accessoires. À ce titre, si l'acheteur fait l'objet d'un redressement ou d'une liquidation judiciaire,
                la société BDE CESI se réserve le droit de revendiquer, dans le cadre de la procédure collective,
                les marchandises vendues et restées impayées.
            </p>
            <br />
            <h2>Clause n° 9 : Livraison</h2>
            <p>La livraison est effectuée :<br />
                <span class="marge">-soit par la remise directe de la marchandise à l'acheteur ;</span><br />
                <span class="marge">-soit par l'envoi d'un avis de mise à disposition en magasin à l'attention de l'acheteur ;</span><br />
                <span class="marge">-soit au lieu indiqué par l'acheteur sur le bon de commande.</span><br />
                Le délai de livraison indiqué lors de l'enregistrement de la commande n'est donné qu'à titre indicatif et n'est aucunement garanti.<br />
                Par voie de conséquence, tout retard raisonnable dans la livraison des produits ne pourra pas donner lieu au profit de l'acheteur à :<br />
                <span class="marge">-l'allocation de dommages et intérêts ;</span><br />
                <span class="marge">-l'annulation de la commande</span>.<br />
                Le risque du transport est supporté en totalité par l'acheteur.<br />
                En cas de marchandises manquantes ou détériorées lors du transport, l'acheteur devra formuler toutes les réserves nécessaires sur le bon de commande à réception desdites marchandises.
                Ces réserves devront être, en outre, confirmées par écrit dans les cinq jours suivant la livraison, par courrier recommandé AR.
            </p>
            <br />
            <h2>Clause n° 10 : Force majeure</h2>
            <p>La responsabilité de la société BDE CESI ne pourra pas être mise en oeuvre si la non-exécution ou le retard
                dans l'exécution de l'une de ses obligations décrites dans les présentes conditions générales de vente découle d'un cas de force majeure.
                À ce titre, la force majeure s'entend de tout événement extérieur, imprévisible et irrésistible au sens de l'article 1148 du Code civil.
            </p>
            <br />
            <h2>Clause n° 11 : Tribunal compétent</h2>
            <p>Tout litige relatif à l'interprétation et à l'exécution des présentes conditions générales de vente est soumis au droit français.</p>
            <br /><br />
        </div>
        <?php include('footer.php'); ?>
        <!-- on inclut le footer -->
    </div>
</body>