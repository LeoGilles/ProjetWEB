<?php

try
{
	// On se connecte à MySQL
	$bdd = new PDO('mysql:host=localhost;dbname=projetweb;charset=utf8', 'root', '');
}
catch(Exception $e)
{
	// En cas d'erreur, on affiche un message et on arrête tout
        die('Erreur : '.$e->getMessage());
}




 $idphotos = $donn['id'];
  $photos = $bdd->prepare('CALL `selectcom`(:p0);');
  $photos->bindValue(':p0', $idphotos , PDO::PARAM_STR); 
  $photos->execute(); 
   while($photosres = $photos->fetch()){       ?>
<?php if($_SESSION['role'] == 3){ ?>
  <a href="delcom.php" onclick="delcom(<?php echo ($photosres['idcom'])?>)" class="buttonmois blacklinkbuttonimage" >Supprimer ce commentaire </a>   
<?php } ?>
<div class="containercom">
  <img src="./image/<?php echo($donn['url']);?> " alt="Avatar">
  <p> <?php echo($photosres['contenu']);?></p>
  <span class="time-right">Posté par <?php echo($photosres['nom']);?> <?php echo($photosres['prenom']);?></span>
</div>
<?php  } $photos->closeCursor(); ?>