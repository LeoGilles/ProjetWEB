<?php

try {
  // On se connecte à MySQL
  $bdd = new PDO('mysql:host=localhost;dbname=projetweb;charset=utf8', 'root', '');
} catch (Exception $e) {
  // En cas d'erreur, on affiche un message et on arrête tout
  die('Erreur : ' . $e->getMessage());
}

//procédure stockée pour sélectioner les commentaires et les afficher
$idphotos = $donn['id'];
$photos = $bdd->prepare('CALL `selectcom`(:p0);');
$photos->bindValue(':p0', $idphotos, PDO::PARAM_STR);
$photos->execute();
while ($photosres = $photos->fetch()) {    // on affiche le résultat de la requête ligne par ligne    
  ?>
  <?php if ($_SESSION['role'] == 3) { ?>
    <br /><br /> <!-- si l'utilisateur est un membre du BDE on affiche un bouton pour supprimer le commentaire associé -->
    <a href="delcom.php" onclick="delcom(<?php echo ($photosres['idcom']) ?>)" class="buttondelcom blacklinkbuttonimage">Supprimer ce commentaire </a>
  <?php } ?>
  <!--affichage du commentaire -->
  <div class="containercom">
    <img src="./image/<?php echo ($donn['url']); ?> " alt="Avatar">
    <p> <?php echo ($photosres['contenu']); ?></p>
    <span class="time-right">Posté par <?php echo ($photosres['nom']); ?> <?php echo ($photosres['prenom']); ?></span>
  </div>
<?php  }
$photos->closeCursor(); ?>