<?php
session_start();
session_destroy(); //fonction pour se déconnecter
header('Location: ./main.php');
