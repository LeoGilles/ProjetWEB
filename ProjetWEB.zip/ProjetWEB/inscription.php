<?php
session_start(); // on démarre la session
try {
        // On se connecte à MySQL
        $bdd = new PDO('mysql:host=localhost;dbname=projetweb;charset=utf8', 'root', '');
} catch (Exception $e) {
        // En cas d'erreur, on affiche un message et on arrête tout
        die('Erreur : ' . $e->getMessage());
}


$maile = $_POST['mail'];
$motDePass = $_POST['mdp'];
// on appelle une procédure stockée pour savoir si cet utilisateur éxiste déja dans la BDD
$raque = $bdd->prepare('CALL `samepseudo`(:p3);');
$raque->bindValue(':p3', $maile, PDO::PARAM_STR);
$raque->execute();
$donne2 = $raque->fetch();
$raque->closeCursor();


$nom = $_POST['nom'];
$prenom = $_POST['prenom'];
$remember = $_POST['remember'];
$repmdp = $_POST['repmdp'];
$local = $_POST['local'];

if ($donne2['adresse_mail'] == $_POST['mail']) {
        echo ("Ce Mail est Déja utilisé");
} else if ($repmdp != $motDePass) {
        echo ("Les mots de passes ne corespondent pas. ");
} else {
        //procédure stockée pour ajouter un utilisateur à la BDD
        $requete = $bdd->prepare('CALL `addusers`(:p0,:p1,:p2,:p3,:p4);');

        $requete->bindValue(':p0', $nom, PDO::PARAM_STR);
        $requete->bindValue(':p1', $prenom, PDO::PARAM_STR);
        $requete->bindValue(':p2', $local, PDO::PARAM_STR);
        $requete->bindValue(':p3', $maile, PDO::PARAM_STR);
        $requete->bindValue(':p4', $motDePass, PDO::PARAM_STR);
        $requete->execute();
        $donne = $requete->fetch();

        $requete->closeCursor();

        $_SESSION['id'] = $donne2['id'];
        $_SESSION['adresse_mail'] = $donne2['adresse_mail'];
        $_SESSION['role'] = $donne2['role'];
        $_SESSION['nom'] = $donne2['nom'];
        $_SESSION['prenom'] = $donne2['prenom'];
        if ($remember == on) {
                // si l'utilisateur souhaite que l'on se souvienne de lui on met en place ses cookies
                $_COOKIE['mail'] = $donne2['mail'];
                $_COOKIE['categorie'] = $donne2['categorie'];
                $_COOKIE['nom'] = $donne2['nom'];
                $_COOKIE['prenom'] = $donne2['prenom'];
        }
        header('Location: ./main.php');
}
