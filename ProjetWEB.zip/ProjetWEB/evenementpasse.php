<?php include('header.php'); ?> 

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel='stylesheet' href='activite.css' />
    <title>Liste des activités</title>
</head>

<body>

    <div class="content">
        <img src="./image/loisirs.jpg" alt="imageloisirs" class="imgloisirs" />

        <div class="vieprivee">
            <br />
            <?php
            if ($_SESSION['role'] == 2) {
                // si l'utilisateur est un salarié , il peut télécharger l'ensemble des photos du site
                include("staffCesi.php");
            }
            ?>
            <br /><br />
            <?php include("bddevenementpasse.php"); ?>

        </div>
        <?php include('footer.php'); ?>
    </div>




</body>

<script src="./vendors/jquery/jquery-3.4.1.min.js"></script>
<script src="./vendors/bootstrap/js/bootstrap.bundle.min.js"></script>
<script>
    // Get the modal
    var modal = document.getElementById('id01');

    // When the user clicks anywhere outside of the modal, close it
    window.onclick = function(event) {
        if (event.target == modal) {
            modal.style.display = "none";
        }
    }
</script>




</html>