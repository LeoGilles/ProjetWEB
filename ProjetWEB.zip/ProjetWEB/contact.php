<?php include('header.php'); ?>
<!-- on inclut le header -->

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <link rel='stylesheet' href="contact.css" />
    <TItle>Contacts</TItle>
</head>

<body>
    <div class="content">
        <img src="./image/contact.jpg" alt="contact image" class="contactimg" />
        <br /><br /><br />
        <div class="contactbde">
            <h2>Contacts</h2>
            <p>Vous pouvez nous contacter par mail aux adresses suivantes :</p><br />
            <p>leo.gilles@viacesi.fr<br />
                titouan.lambrecq@viacesi.fr<br />
                marcadrien.pointel@viacesi.fr<br />
                bastien.aelters@viacesi.fr</p>
            <br /><br />
        </div>
        <?php include('footer.php'); ?>
        <!-- on inclut le footer -->
    </div>

</body>