<?php
session_start();

$nav=0;
if ( (isset($_POST['m']) )  ){ 
$_SESSION['insc']['com'] = $_POST['m'];
echo "Completer le formulaire .";

}
else{
$event = $_SESSION['insc']['com'];    
$contenu = $_POST['com'];
$idmembres = $_SESSION['id'];
try
{
	// On se connecte à MySQL
	$bdd = new PDO('mysql:host=localhost;dbname=projetweb;charset=utf8', 'root', '');
}
catch(Exception $e)
{
	// En cas d'erreur, on affiche un message et on arrête tout
        die('Erreur : '.$e->getMessage());
}

    $insc = $bdd->prepare('CALL `addcom`(:p1,:p2,:p3);');
    $insc->bindValue(':p1', $idmembres , PDO::PARAM_STR); 
    $insc->bindValue(':p2', $event , PDO::PARAM_STR); 
    $insc->bindValue(':p3', $contenu , PDO::PARAM_STR); 
    $insc->execute();
    $donne = $insc->fetch();
    $insc->closeCursor();
      header('Location: ./evenementpasse.php');
  
     
}
?>