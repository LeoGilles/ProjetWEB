<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="./footer.css" />
</head>

<body>
    <footer class="footer">
        <br />
        <p>Retrouvez notre actualité sur :</p>
            <!-- lien vers les réseaux sociaux et les mentions légales -->
        <a href="https://www.facebook.com/bdecesirouen/" class="fa fa-facebook fas2"></a>
        <a href="https://twitter.com/cesi_rouen" class="fa fa-twitter fas3"></a>
        <a href="https://www.instagram.com/campus_cesi/?hl=fr" class="fa fa-instagram fas4"></a>
        <a href="https://fr.linkedin.com/company/cesicampusrouen" class="fa fa-linkedin fas5"></a> <br /> <br /> <br />

        <a href="http://localhost/Projetweb/politique.php">Politique de confidentialité - Mentions Légales - About us </a>
        <br /><br />
        <a href="./cgv.php">Conditions générales de ventes</a>
    </footer>

</body>


<script src="./vendors/jquery/jquery-3.4.1.min.js"></script>
<script src="./vendors/bootstrap/js/bootstrap.bundle.min.js"></script>
<script>
    // Get the modal
    var modal = document.getElementById('id01');

    // When the user clicks anywhere outside of the modal, close it
    window.onclick = function(event) {
        if (event.target == modal) {
            modal.style.display = "none";
        }
    }
</script>

</html>