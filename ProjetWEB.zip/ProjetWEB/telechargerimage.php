<?php

$zip = new ZipArchive(); //instanciation de la classe ZipArchive (elle permet de gérer une archive de type zip)
if ($zip->open("Image.zip", ZipArchive::CREATE) == True) //on crée une nouvelle archive et on l'ouvre, le tout dans une condition pour etre sur que le dossier existe
{
  $rep = scandir('./image/'); //permet de récupérer l'ensemble des données du fichier "image" sous forme d'un tableau
  unset($rep[0], $rep[1]); //On supprime "." et ".." qui sont les chemins du dossier courant et parent
  foreach ($rep as $file) { //on stock pour chaque valeur du tableau contenu dans $rep dans une variable temporaire $file
    $zip->addfile('./image/' . $file); //on ajoute dans la variable $zip l'ensemble des fichiers que l'on souhaite en spécifiant le chemin
  }
  $zip->close(); // on ferme l'archive

  //L'ensemble des fonctions headers servent au téléchargement du fichier.zip
  header('Content-Transfer-Encoding: binary'); //Transfert en binaire (fichier).
  header('Content-Disposition: attachment; filename="Image.zip"'); //Nom du fichier.
  header('Content-Length: ' . filesize('Image.zip')); //Taille du fichier.

  //Permet de lire et d'envoyer le fichier Image.zip
  readfile('Image.zip');
}
?>













http://frankbecu.unblog.fr/2015/02/13/creer-et-telecharger-une-archive-en-php/
http://sdz.tdct.org/sdz/les-fonctions-zip-en-php.html