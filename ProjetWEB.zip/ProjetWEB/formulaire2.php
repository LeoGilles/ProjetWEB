<meta charset="utf-8" />
<?php
// Connexion à la base de données
try {
  $bdd = new PDO('mysql:host=localhost;dbname=projetweb;charset=utf8', 'root', '');
} catch (Exception $e) {
  die('Erreur : ' . $e->getMessage());
}

$addPhoto = $_FILES['monfichier']['name'];
//on définit le fuseau horraire 
date_default_timezone_set('Europe/Paris');
$dateTime = date("Y-m-d H:i:s");
//si les données du formulaire sont correctes , on appelle la procédure stockée pour ajouter une activité à la BDD
if (isset($_POST['pseudo'], $_POST['titreArticle'], $_POST['contenuArticle']) and !empty($_POST['pseudo'])  and !empty($_POST['titreArticle'])  and !empty($_POST['contenuArticle'])) {

  $pseudo = htmlspecialchars($_POST['pseudo']);

  $titreArticle = htmlspecialchars($_POST['titreArticle']);

  $contenuArticle = htmlspecialchars($_POST['contenuArticle']);

  $insertionTable = $bdd->prepare('CALL `testForm2`(:p0,:p1,:p2,:p3,:p4);');

  $insertionTable->bindValue(':p0', $pseudo, PDO::PARAM_STR);
  $insertionTable->bindValue(':p1', $addPhoto, PDO::PARAM_STR);
  $insertionTable->bindValue(':p2', $titreArticle, PDO::PARAM_STR);
  $insertionTable->bindValue(':p3', $contenuArticle, PDO::PARAM_STR);
  $insertionTable->bindValue(':p4', $dateTime, PDO::PARAM_STR);

  $insertionTable->execute();
  $insertionTable->closeCursor();
  // on déplace le fichier uploadé dans un dossier contenant l'ensemble des images du site
  move_uploaded_file($_FILES['monfichier']['tmp_name'], 'image/' . basename($_FILES['monfichier']['name']));
} else {
  $formError = "Un des champs est vide";
}
header('Location: ./main.php');
