<?php 
session_start();
try
{
	// On se connecte à MySQL
	$bdd = new PDO('mysql:host=localhost;dbname=projetweb;charset=utf8', 'root', '');
}
catch(Exception $e)
{
	// En cas d'erreur, on affiche un message et on arrête tout
        die('Erreur : '.$e->getMessage());
}


$maile = $_POST['mail']; 
$motDePass = $_POST['mdp']; 

$raque = $bdd->prepare('CALL `samepseudo`(:p3);');
$raque->bindValue(':p3', $maile , PDO::PARAM_STR); 
$raque->execute();
$donne2 = $raque->fetch();
$raque->closeCursor();


if ($donne2['adresse_mail'] != $_POST['mail'])
{
       echo("Votre mail et/ou mot de passe est incorect veuillez réesayer.");
       
       
    ?><a href="./main.php"> <button>Retourner sur la page de connexion</button></a>
    <?php  
}
else if($donne2['mdp'] != $_POST['mdp'])
    {    
            
           echo("Votre test et/ou mot de passe est incorect veuillez réesayer.");
        
    ?> <a href="./main.php"> <button>Retourner sur la page de connexion</button></a>
    <?php 
    }
    else{
        $_SESSION['id'] = $donne2['id'];
        $_SESSION['adresse_mail'] = $donne2['adresse_mail'];
        $_SESSION['role'] = $donne2['role'];
        $_SESSION['localisation'] = $donne2['localisation'];
        $_SESSION['nom'] = $donne2['nom'];
        $_SESSION['prenom'] = $donne2['prenom'];
            header('Location: ./main.php');
            exit();
        }

                ?>