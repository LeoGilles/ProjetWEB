<meta charset="utf-8" />
  <?php
  // Connexion à la base de données
  try
  {
  	$bdd = new PDO('mysql:host=localhost;dbname=projetweb;charset=utf8', 'root', '');
  }
  catch(Exception $e)
  {
          die('Erreur : '.$e->getMessage());
  }

$addPhoto = $_FILES['monfichier']['name'];

date_default_timezone_set('Europe/Paris');
$dateTime = date("Y-m-d H:i:s");
            if(isset($_POST['pseudo'],$_POST['titreArticle'],$_POST['contenuArticle']) AND !empty($_POST['pseudo'])  AND !empty($_POST['titreArticle'])  AND !empty($_POST['contenuArticle']
            ))  {
               
              $pseudo = htmlspecialchars($_POST['pseudo']);

              $titreArticle = htmlspecialchars($_POST['titreArticle']);

              $contenuArticle = htmlspecialchars($_POST['contenuArticle']);

              $insertionTable = $bdd->prepare('CALL `testForm`(:p0,:p1,:p2,:p3,:p4);');

              $insertionTable->bindValue(':p0', $pseudo , PDO::PARAM_STR);
              $insertionTable->bindValue(':p1', $addPhoto , PDO::PARAM_STR);
              $insertionTable->bindValue(':p2', $titreArticle , PDO::PARAM_STR);
              $insertionTable->bindValue(':p3', $contenuArticle , PDO::PARAM_STR);
              $insertionTable->bindValue(':p4', $dateTime , PDO::PARAM_STR);
              
              $insertionTable->execute();
              $insertionTable->closeCursor();
              move_uploaded_file($_FILES['monfichier']['tmp_name'], 'image/' . basename($_FILES['monfichier']['name']));
            }else {
              $formError = "Un des champs est vide";
            }
            header('Location: ./main.php');