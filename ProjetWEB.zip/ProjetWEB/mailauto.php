<?php

try {
	// On se connecte à MySQL
	$bdd = new PDO('mysql:host=localhost;dbname=projetweb;charset=utf8', 'root', '');
} catch (Exception $e) {
	// En cas d'erreur, on affiche un message et on arrête tout
	die('Erreur : ' . $e->getMessage());
}
$getid = $_SESSION['id'];
//procédure stockée pour récuperer les mails des membres du BDE
$requete = $bdd->prepare('CALL `mailbde`;');
$requete->execute();
?>
<!-- boutton pour envoyer un mail de notification aux membres du BDE  que quelqun a passé une commande , -->
<!-- pour automatiser le processus nous aurions besoins d'un serveur en ligne(impossible en local)-->
<a href="mailto:<?php while ($mailbde = $requete->fetch()) {
					echo ($mailbde['adresse_mail'] . ', ');
				} ?>?subject=Commande sur la boutique&body=L'Etudiant <?php echo ($_SESSION['nom'] . ' ' . $_SESSION['prenom']); ?> à passé commande."> oui </a>

<?php
$requete->closeCursor();
?>