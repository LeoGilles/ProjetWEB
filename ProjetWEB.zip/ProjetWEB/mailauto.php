<?php

try
{
	// On se connecte à MySQL
	$bdd = new PDO('mysql:host=localhost;dbname=projetweb;charset=utf8', 'root', '');
}
catch(Exception $e)
{
	// En cas d'erreur, on affiche un message et on arrête tout
        die('Erreur : '.$e->getMessage());
}
$getid = $_SESSION['id'];
$requete = $bdd->prepare('CALL `mailbde`;');
$requete->execute();
?>
<a href="mailto:<?php while ($mailbde = $requete->fetch()){echo ($mailbde['adresse_mail'] . ', '); }?>?subject=Commande sur la boutique&body=L'Etudiant <?php echo($_SESSION['nom'] . ' ' . $_SESSION['prenom']); ?> à passé commande."> oui </a>

<?php
$requete->closeCursor();
?>
