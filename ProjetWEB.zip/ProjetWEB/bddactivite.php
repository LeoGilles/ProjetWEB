<?php
session_start();
try {
    // On se connecte à MySQL
    $bdd = new PDO('mysql:host=localhost;dbname=projetweb;charset=utf8', 'root', '');
} catch (Exception $e) {
    // En cas d'erreur, on affiche un message et on arrête tout
    die('Erreur : ' . $e->getMessage());
}

$raque = $bdd->prepare('CALL `allactivites`;');
$raque->execute();

$membre = $_SESSION['id'];

while ($donnes = $raque->fetch()) { //on affiche toute les activité ligne par ligne

    $idevent = $donnes['id'];
    //procédure stockée pour sélectionner les activité auquel l'utilisateur s'est inscrit
    $insc = $bdd->prepare('CALL `selectactivite`(:p2,:p3);');
    $insc->bindValue(':p2', $membre, PDO::PARAM_STR);
    $insc->bindValue(':p3', $idevent, PDO::PARAM_STR);
    $insc->execute();
    $donne = $insc->fetch();
    $insc->closeCursor();

    if ($_SESSION['role'] == 3) { ?>
        <!-- Si l'utilisateur est un membre du BDE on affiche un boutton pour qu'il télécharge la liste des inscrits de cette activité -->
        <a href="download.php" class="buttonimage" onclick="down( <?php echo ($donnes['id']) ?>)">Telecharger la liste des Inscrits pour cette activité </a> <?php
                                                                                                                                                                    } ?>
    <!-- on affiche les activités -->
    <div class='card'>
        <img src='image/<?php echo ($donnes['photo']); ?>' alt='leophoto' class='photoArticle'>
        <h1><?php echo ($donnes['titre']); ?></h1>
        <p class='price'>Créée par <?php echo ($donnes['pseudo']); ?> le <?php echo ($donnes['date_creation']); ?></p>
        <p><?php echo ($donnes['contenu']); ?></p>
        <?php if ($_SESSION['role'] == 1) {
                if ($_SESSION['id'] != $donne['id_membre']) {  ?>
                <!-- si l'utilisateur est un étudiant et qu'il n'est pas encore inscrit on affiche le boutton d'inscrition -->
                <a href="inscactivite.php" class="buttonmois" onclick="go( <?php echo ($donnes['id']) ?>)">S'inscrire</a>

            <?php }
                }
                if ($_SESSION['role'] == 2) { ?>
            <!-- si l'utilisateur est un salarié on affiche le boutton-->
            <a><button class="buttonmois">Vous n'êtes pas étudiants</button></a>
        <?php }
            if ($_SESSION['role'] == null) { ?>
            <!-- si l'utilisateur n'est pas connecté on affiche le boutton-->
            <a><button class="buttonmois">Connectez vous pour vous inscrire</button></a>
            <?php  }
                if ($_SESSION['id'] == $donne['id_membre']) {
                    if ($_SESSION['role'] == 1) { ?>
                <!-- si l'utilisateur est un étudiant et qu'il est déja inscrit on affiche le boutton de désinscrition -->
                <a href="desactivite.php" class="buttonmois" onclick="ungo( <?php echo ($donnes['id']) ?>)">Se désinscrire</a>
        <?php }
            } ?>
    </div>
    <br /><br /> <?php      }
                    $raque->closeCursor();

                    ?>

<script type='text/JavaScript'>
    function go(nav){
                $.ajax({                //fonction ajax appellé pour s'inscrire à un évenemenent
		    type: "POST",
		    url: './inscactivite.php',
			data:"m=" + nav ,
		    success:
		    function(retour){
		        alert(retour );
		    }}); 
            }
          </script>
<script type='text/JavaScript'>
    function ungo(nav){
                $.ajax({         //fonction ajax appellé pour se désinscrire à un évenemenent
		    type: "POST",
		    url: './desactivite.php',
			data:"m=" + nav ,
		    success:
		    function(retour){
		        alert(retour );
		    }}); 
            }
          </script>