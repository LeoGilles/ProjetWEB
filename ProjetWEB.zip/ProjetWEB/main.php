<?php include('header.php'); ?>
<!-- On inclut le header de la page -->

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel='stylesheet' href="evenementdumois.css" />
    <!--On inclut le css de cette page -->
    <TItle>BDE Cesi</TItle>
</head>

<body>
    <div class="content">
        <img src="./image/Cesirouen.jpg" alt="BDE Cesi rouen" class="imgrouen" />
        <!--image de fond -->
    </div>

    <div class="eventmois">
        <br /><br />
        <img src="./image/flechebas.png" alt="Fleche vers le bas" class="flechebas" /> <!-- image de Fleche -->
        <br /><br />

        <?php include('evenementdumois.php'); ?>
        <!--On inclut l'évenement du mois (l'affichage sur la page d'acceuil) -->

    </div>

    <?php include('footer.php'); ?>
    <!--On inclut le footer -->

</body>

<script src="./vendors/jquery/jquery-3.4.1.min.js"></script>
<!--On inclut Jquery -->

<script src="./vendors/bootstrap/js/bootstrap.bundle.min.js"></script>
<!--On inclut Bootstrap -->

<script>
    var modal = document.getElementById('id01'); // Script pour faire aapparaitre et disparaitre les formulaires

    window.onclick = function(event) {
        if (event.target == modal) {
            modal.style.display = "none";
        }
    }
</script>

<script>
    function myAjax() {
        $.ajax({
            type: "POST",
            url: 'inscevent.php',
            data: {
                action: '<?php echo ($idmax['id']); ?>'
            }, // Fonction ajax pour ajouter un évenement
            success: function(html) {
                <?php $_SESSION['insc']['id'] = $idmax['id']; ?>
            }
        });
    }
</script>

</html>