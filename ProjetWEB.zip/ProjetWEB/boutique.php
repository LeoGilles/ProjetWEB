<?php 
session_start();
$nav=0;
if ( (isset($_POST['m']) )  ){ 
$_SESSION['panier']['id'] = $_POST['m'];

try
{
	// On se connecte à MySQL
	$bdd = new PDO('mysql:host=localhost;dbname=projetweb;charset=utf8', 'root', '');
}
catch(Exception $e)
{
	// En cas d'erreur, on affiche un message et on arrête tout
        die('Erreur : '.$e->getMessage());
}

$id = $_SESSION['id'];
$idarticle = $_SESSION['panier']['id'];

$verif = $bdd->prepare('CALL `selectpanier`(:p2,:p3);');
$verif->bindValue(':p2', $id , PDO::PARAM_STR); 
$verif->bindValue(':p3', $idarticle , PDO::PARAM_STR);
$verif->execute();
$ver = $verif->fetch();
$verif->closeCursor();

if($ver['qte'] >= 2 && $ver['id_membre'] == $id){

    $insc = $bdd->prepare('CALL `remqte`(:p2,:p3);');
    $insc->bindValue(':p2', $id , PDO::PARAM_STR); 
    $insc->bindValue(':p3', $idarticle , PDO::PARAM_STR); 
    $insc->execute();
    $donne = $insc->fetch();
    $insc->closeCursor();
    echo ("Vous avez supprimé cet article de votre panier");
    
}
if( $ver['qte'] == 1 ){

$insc = $bdd->prepare('CALL `rempanier`(:p2,:p3);');
$insc->bindValue(':p2', $id , PDO::PARAM_STR); 
$insc->bindValue(':p3', $idarticle , PDO::PARAM_STR); 
$insc->execute();
$donne = $insc->fetch();
$insc->closeCursor();
echo ("Vous avez supprimé cet article de votre panier");

}


}
else{ ?>

<!-- Inclut le fichier header.php -->
<?php include('header.php'); ?>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel='stylesheet' href='boutique.css'/>
    
    <TItle>Boutique</TItle>
</head>

<body >
    <!-- Caroussel -->
    <div class="slideshow">
		<ul>
			<li><img src="./image/pullv.jpg" alt="image carroussel 1" class="imgcar"/></li>
				<li><img src="./image/tshirtlacoste.jpg" alt="image carroussel 2" class="imgcar"/></li>
				<li><img src="./image/tshirtlv.jpg" alt="image carroussel 3" class="imgcar"/></li>
		</ul>
	</div>
    
    <div class="barrecherche">
    <a href="#about" data-toggle="modal" data-target="#boutique">Ajouter des critères</a>
     	
    </div>

    <div class="articlecontainer">
    <?php include('affichagearticle.php'); ?>
    <br />
    <!-- Inclut le fichier footer.php -->
   <?php include('footer.php'); ?>
    </div>   
    
    
<!-- Inclut le script nécessaire à l'animation du caroussel -->
<script type="text/javascript" src="boutique.js"></script>    
</body>
 

<script src="./vendors/jquery/jquery-3.4.1.min.js"></script>
<script src="./vendors/bootstrap/js/bootstrap.bundle.min.js"></script>
<script>
// Get the modal
var modal = document.getElementById('id01');

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}

function delArt(nav){
                $.ajax({
		    type: "POST",
		    url: './delArt.php',
			data:"m=" + nav ,
		    success:
		    function(retour){
		        
		    }}); 
            } 

            function addpanier(nav){
                $.ajax({
		    type: "POST",
		    url: './panier.php',
			data:"m=" + nav ,
		    success:
		    function(retour){
		        alert(retour);
		    }}); 
            } 


</script>

</html>
<?php
        }