<!-- Inclut le fichier header.php -->
<?php include('header.php'); ?>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel='stylesheet' href='boutique.css'/>
    
    <TItle>Boutique</TItle>
</head>

<body >
    <!-- Caroussel -->
    <div class="slideshow">
		<ul>
			<li><img src="./image/pullv.jpg" alt="image carroussel 1" class="imgcar"/></li>
				<li><img src="./image/tshirtlacoste.jpg" alt="image carroussel 2" class="imgcar"/></li>
				<li><img src="./image/tshirtlv.jpg" alt="image carroussel 3" class="imgcar"/></li>
		</ul>
	</div>
    
    <div class="barrecherche">

        <input type="text" placeholder="rechercher...">

        <p class="categorylist">
			<label for="local"><b>Categorie</b></label>
            <select type="select" id="categorie" name="categorie">
			<option value="all">Tout les produits</option>
			<option value="bonnet">Bonnet</option>
			<option value="pull">Pull</option>
			<option value="shirt">T-shirt</option>
            <option value="casquette">Casquette</option>
            <option value="voiture">Voiture</option>
            </select>		
            <br />	
		</p>
        <br />
        <p class="filtreprix">  
			Prix allant de :
            <label for="MinPrice" class="MinPrice" ></label>
            
            <input id="MinPrice" name="MinPrice" type="number" placeholder="Prix minimum" min="0" max="99999999999"/>
			€
			à :
			<label for="MaxPrice" class="MaxPrice" ></label>
            <input id="MaxPrice" name="MaxPrice" type="number" placeholder="Prix maximum" min="0" max="99999999999"/>
			€
									
        </p>
        
    </div>

    <div class="articlecontainer">
    <?php include('affichagearticle.php'); ?>
<br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br />
    <!-- Inclut le fichier footer.php -->
   <?php include('footer.php'); ?>
    </div>   
    
    
<!-- Inclut le script nécessaire à l'animation du caroussel -->
<script type="text/javascript" src="boutique.js"></script>    
</body>
 

<script src="./vendors/jquery/jquery-3.4.1.min.js"></script>
<script src="./vendors/bootstrap/js/bootstrap.bundle.min.js"></script>
<script>
// Get the modal
var modal = document.getElementById('id01');

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}

function delArt(nav){
                $.ajax({
		    type: "POST",
		    url: './delArt.php',
			data:"m=" + nav ,
		    success:
		    function(retour){
		        
		    }}); 
            } 

</script>

</html>