<!-- Inclut le fichier header.php -->
<?php include('header.php'); ?>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel='stylesheet' href='boutique.css'/>
    
    <TItle>Boutique</TItle>
</head>

<body >
    <!-- Caroussel -->
    <div class="slideshow">
		<ul>
			<li><img src="./image/banane.jpg" alt="" class="imgcar"/></li>
				<li><img src="./image/cochon.jpg" alt="" class="imgcar"/></li>
				<li><img src="./image/roland.jpg" alt="" class="imgcar"/></li>
		</ul>
	</div>
    
    <div class="barrecherche">
        <input type="text" placeholder="rechercher...">

        <p class="categorylist">
			<select name="Category" size="1">
			<option>Tous les produits
			<option>Vêtements
			<option>Alimentaire
			<option>Accessoires
			<option>Voiture
			</select>			
		</p>

        <p class="filtreprix">  
			Prix allant de :
			<label for="MinPrice" class="MinPrice" ></label>
            <input id="MinPrice" name="MinPrice" type="number" placeholder="Prix minimum" min="0" max="99999999999"/>
			€
			à :
			<label for="MaxPrice" class="MaxPrice" ></label>
            <input id="MaxPrice" name="MaxPrice" type="number" placeholder="Prix maximum" min="0" max="99999999999"/>
			€
									
        </p>
    </div>
    <br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br />
    <!-- Inclut le fichier footer.php -->
    <?php include('footer.php'); ?>
    
<!-- Inclut le script nécessaire à l'animation du caroussel -->
<script type="text/javascript" src="boutique.js"></script>    
</body>


<script src="./vendors/jquery/jquery-3.4.1.min.js"></script>
<script src="./vendors/bootstrap/js/bootstrap.bundle.min.js"></script>
<script>
// Get the modal
var modal = document.getElementById('id01');

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
</script>

</html>