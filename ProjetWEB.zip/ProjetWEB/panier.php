<?php 
session_start();
$nav=0;
if ( (isset($_POST['m']) )  ){ 
$_SESSION['panier']['id'] = $_POST['m'];

try
{
	// On se connecte à MySQL
	$bdd = new PDO('mysql:host=localhost;dbname=projetweb;charset=utf8', 'root', '');
}
catch(Exception $e)
{
	// En cas d'erreur, on affiche un message et on arrête tout
        die('Erreur : '.$e->getMessage());
}
$id = $_SESSION['id'];
$idarticle =$_SESSION['panier']['id'];
$verif = $bdd->prepare('CALL `selectpanier`(:p2,:p3);');
$verif->bindValue(':p2', $id , PDO::PARAM_STR); 
$verif->bindValue(':p3', $idarticle , PDO::PARAM_STR); 
$verif->execute();
$ver = $verif->fetch();
$verif->closeCursor();

if($ver['qte'] >= 1 && $ver['id_membre'] == $id){

    $insc = $bdd->prepare('CALL `addqte`(:p2,:p3);');
    $insc->bindValue(':p2', $id , PDO::PARAM_STR); 
    $insc->bindValue(':p3', $idarticle , PDO::PARAM_STR); 
    $insc->execute();
    $donne = $insc->fetch();
    $insc->closeCursor();
    echo ("Vous avez ajouté cet article à votre panier");
    


}
if($ver['id_membre'] != $id){

$insc = $bdd->prepare('CALL `addpanier`(:p2,:p3);');
$insc->bindValue(':p2', $id , PDO::PARAM_STR); 
$insc->bindValue(':p3', $idarticle , PDO::PARAM_STR); 
$insc->execute();
$donne = $insc->fetch();
$insc->closeCursor();
echo ("Vous avez ajouté cet article à votre panier");

}


}
else{  ?> 
<?php



    include('header.php'); ?>

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <link rel='stylesheet' href='activite.css'/>
        
        <TItle>Panier</TItle>
    </head>
    
    <body >
                
            
            <div class="containerpanier">
            <br /><br /><br /><br />
            <h1 style="text-align:center;">Votre Panier : </h1>
            <br /><br />
    <?php

try
{
	// On se connecte à MySQL
	$bdd = new PDO('mysql:host=localhost;dbname=projetweb;charset=utf8', 'root', '');
}
catch(Exception $e)
{
	// En cas d'erreur, on affiche un message et on arrête tout
        die('Erreur : '.$e->getMessage());
}
        $id = $_SESSION['id'];
        
        $sel = $bdd->prepare('CALL `allpanier`(:p2);');
        $sel->bindValue(':p2', $id , PDO::PARAM_STR); 
        $sel->execute();
        while($donne = $sel->fetch()){ ?>
            <div class="containercom">

            <img src="./image/<?php echo($donne['url']);?> " alt="Avatar">
            <h1><?php echo($donne['nom']);?></h1>
            <p> Description : <?php echo($donne['description']);?></p>
            <span > Coût : <?php echo($donne['prix']);?> € , Quantité : x<?php echo($donne['qte']);?></span>
           
            <a href="" onclick="rempanier(<?php echo ($donne['id'])?>)" class="rightrem blacklinkbuttonimage" >  Supprimer cet article de votre panier </a>  
          </div>
      <?php  } $sel->closeCursor();  
      if($_SESSION['role'] == 3 || $_SESSION['role'] == 2){?>
        <h1>Vous n'etes pas étudiant , vous n'avez donc pas de panier. Pour plus de renseignement , contactez le BDE</h1>
      <?php } ?>
      <br />
      <a href="mailauto.php" class="buttonmois blacklinkbuttonimage" > Payer/envoyer un mail aux membres du BDE </a>   

        </div>
    <?php include('footer.php'); ?>

    </body>
    <script>

     function rempanier(nav){
                $.ajax({
		    type: "POST",
		    url: './boutique.php',
			data:"m=" + nav ,
		    success:
		    function(retour){
		        alert(retour);
		    }}); 
            }
    
    </script>
<?php
}

