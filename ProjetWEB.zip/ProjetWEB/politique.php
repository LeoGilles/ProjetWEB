<?php include('header.php'); ?>


<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="./politique.css" />
</head>

<body>
    <!-- Page content -->
    <div class="content">
        <img src="./image/legal.png" alt="mentionlegal" class="imglegal" />
        <div class="vieprivee">
            <br /><br />
            <h2>Respect de la vie privée et collecte des Données Personnelles</h2>
            <p>Soucieux de protéger la vie privée de ses clients, CESI s’engage dans la protection des données personnelles.<br>
                Une politique sur la protection des données personnelles rappelle nos principes et nos actions visant au respect de la réglementation applicable en matière de protection des données à caractère personnel.</p>



            <h2>Sécurité</h2>
            <p>Le CESI s’engage à mettre en œuvre tous les moyens nécessaires au bon fonctionnement du site.
                Cependant, le CESI ne peut pas garantir la continuité absolue de l’accès aux services proposés par le site.
                Les adhérents sont informés que les informations et services proposés sur le site pourront être interrompus en cas de force majeure et pourront le cas échéant contenir des erreurs techniques.</p>



            <h2>Cookies</h2>
            <p>Nous utilisons des cookies sur notre Site pour les besoins de votre navigation, l’optimisation et la personnalisation de nos Services sur notre plateforme en mémorisant vos préférences.<br><br>

                Vous pouvez à tout moment désactiver les cookies.<br /><br />

                Définition de « cookie » et son utilisation. Un « cookie » est un fichier texte déposé sur votre ordinateur lors de la visite de notre plateforme. Dans votre ordinateur, les cookies sont gérés par votre navigateur internet.<br><br>

                Nous utilisons des cookies sur notre Site pour les besoins de votre navigation, l’optimisation et la personnalisation de nos Services sur notre plateforme en mémorisant vos préférences.<br>
                Les cookies nous permettent aussi de voir comment notre plateforme est utilisée. Nous recueillons automatiquement votre adresse IP et des informations relatives à l’utilisation de notre Site. Notre plateforme peut ainsi se souvenir de votre identité lorsqu’une connexion a été établie entre le serveur et le navigateur web. Les informations fournies précédemment dans un formulaire web pourront ainsi être conservées.<br><br>

                Différents types de cookies sont utilisés sur notre Site :<br /><br />

                Des cookies sont strictement nécessaires au fonctionnement de notre plateforme. Ils vous permettent d’utiliser les principales fonctionnalités de notre plateforme (par exemple l’accès à votre compte). Sans ces cookies, vous ne pourrez pas utiliser notre plateforme normalement.<br>
                Des cookies dits « analytiques » : afin d’améliorer nos services, nous utilisons des cookies de mesures d’audience telles que le nombre de pages vues, le nombre de visites, l’activité des utilisateurs et leur fréquence de retour, notamment grâce aux services de Google Analytics. Ces cookies permettent seulement l’établissement d’études statistiques sur le trafic des utilisateurs sur notre plateforme, dont les résultats sont totalement anonymes pour nous permettre de connaître l’utilisation et les performances de notre plateforme et d’en améliorer le fonctionnement. Accepter ces cookies est une condition nécessaire à l’utilisation de notre plateforme. Si vous les refusez, nous ne pouvons vous garantir une utilisation normale sur notre plateforme.<br>
                Des cookies fonctionnels : Il s’agit des cookies qui nous permettent de personnaliser votre expérience sur notre plateforme en mémorisant vos préférences. Ces cookies peuvent être placés par une tierce partie pour notre compte, mais elle n’est pas autorisée à les utiliser à d’autres fins que celles décrite.<br>
                Des cookies de ciblage : Ces cookies sont liés aux services fournis par des tierces parties, comme les boutons « J’aime » ou « Partager ». Ces cookies sont placés par des tierces parties.<br><br>

                Types de cookies utilisés. Les types de cookies suivants sont utilisés sur ce Site :<br><br>

                Cookies « temporaires » : ce type de cookie est actif dans votre navigateur jusqu’à ce que vous quittiez notre plateforme et expire si vous n’accédez pas au Site pendant une certaine période donnée.<br>
                Cookies « permanents » ou « traceurs » : ce type de cookie reste dans le fichier de cookies de votre navigateur pendant une période plus longue, qui dépend des paramètres de votre navigateur web. Les cookies permanents sont également appelés cookies traceurs.<br>
                Utilisation des cookies de tiers. Nous pouvons recourir à des partenaires tiers, tels que Google Analytics, pour suivre l’activité des visiteurs de notre plateforme ou afin d’identifier vos centres d’intérêt sur notre plateforme et personnaliser l’offre qui vous est adressée sur notre plateforme ou en dehors de notre plateforme. Les informations pouvant ainsi être collectées par des annonceurs tiers peuvent inclure des données telles que des données de géo-localisation ou des informations de contact, comme des adresses électroniques. Les politiques de confidentialité de ces annonceurs tiers fournissent des informations supplémentaires sur la manière dont les cookies sont utilisés.<br><br>

                Nous veillons à ce que les sociétés partenaires acceptent de traiter les informations collectées sur notre plateforme exclusivement pour nos besoins et conformément à nos instructions, dans le respect de la réglementation européenne et s’engagent à mettre en œuvre des mesures appropriées de sécurisation et de protection de la confidentialité des données.<br><br>

                Désactivation des cookies. Vous pouvez à tout moment désactiver les cookies en sélectionnant ` les paramètres appropriés de votre navigateur pour désactiver les cookies (la rubrique d’aide du navigateur utilisé précise la marche à suivre).<br><br>

                Nous attirons votre attention sur le fait que la désactivation des cookies peut réduire ou empêcher l’accessibilité à tout ou partie de certaines fonctions.<br><br>
            </p>

            <h2>Données personnelles et finalités</h2>
            <p>Par donnée à caractère personnel on entend toute information se rapportant à une personne identifiée ou identifiable, notamment par référence à des identifiants tels qu’un nom, un numéro d’identification, des données de localisation, un identifiant en ligne, un ou plusieurs éléments spécifiques propres à l’identité physique, physiologique, génétique, psychique, économique, culturelle ou sociale ainsi qu’à tout autre renseignement que nos clients décident de nous communiquer.<br><br>

                Lorsque vous utilisez notre Site et que vous souhaitez recevoir des informations sur nos offres, via un formulaire de contact, ou bien un formulaire de candidature, nous collectons et traitons des données à caractère personnel vous concernant telles que : votre Civilité, Nom, Prénom, Date de Naissance, Téléphone, Mail, Adresse, Code Postal, Ville.<br><br>

                Nous vous demanderons également de nous transmettre votre adresse email afin d’utiliser cette donnée pour l’envoi d’emails d’informations et de notifications, ainsi que pour la newsletter.<br><br>

                A la fin de votre parcours diplômant, à des fins de statistiques et de renouvellement de nos titres, nous vous solliciterons dans le cadre d’une enquête de suivi des diplômés.<br><br>

                Dans le cadre d’enquêtes de satisfaction, nous pouvons utiliser un outil de mesure de satisfaction des clients. Il vous sera demandé via cet outil de rédiger un avis sur la formation suivie avec CESI.<br>
            </p>


        </div>
        <?php include('footer.php'); ?>
    </div>

</body>



<script src="./vendors/jquery/jquery-3.4.1.min.js"></script>
<script src="./vendors/bootstrap/js/bootstrap.bundle.min.js"></script>
<script>
    // Get the modal
    var modal = document.getElementById('id01');

    // When the user clicks anywhere outside of the modal, close it
    window.onclick = function(event) {
        if (event.target == modal) {
            modal.style.display = "none";
        }
    }
</script>

</html>