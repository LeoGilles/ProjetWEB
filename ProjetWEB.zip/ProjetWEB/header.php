
<?php
// On démarre la session AVANT d'écrire du code HTML
session_start();

// On s'amuse à créer quelques variables de session dans $_SESSION

?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="main.css"/>
     
    <link rel="stylesheet" href="./vendors/bootstrap/css/bootstrap.min.css"/>
    <link rel="stylesheet" href="./vendors/jquery/jquery-3.4.1.min.css"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="purecookie.js" async></script>
    <script src="phonemenu.js" async></script>
    
</head> 

  <nav>
      <!-- Top Navigation Menu Smartphone/tablette -->
  <div class="navphone">
    <a href="http://localhost/Projetweb/main.php" class="activephone">BDE Cesi</a>
    <!-- Navigation links (hidden by default) -->
    <div id="myLinks">

      <?php
        if($_SESSION['role'] == 3){ ?>
          <a href="#about" class="gauchefloat" data-toggle="modal" data-target="#ajout">Ajouter une Activité</a>
        
        <?php }

        if($_SESSION['adresse_mail'] == null){?>
        <p>
      <a href="#Inscription" data-toggle="modal" data-target="#exampleModal" class="droitefloat">Inscription</a>
      <a href="#connexion" data-toggle="modal" data-target="#conex" class="droitefloat">Connexion</a>
    
    
      <?php }
      else { ?> 
    
      <a href="deconnexion.php" class="droitefloat">Déconnexion</a>
      <?php } ?> 
      <a href="activite.php">Activité</a>
      <a href="evenementpasse.php">Evénements passés</a>
      <a href="boutique.php">boutique</a>
      <a href="contact.php">Contact</a>
    </div>
    <!-- "Hamburger menu" / "Bar icon" to toggle the navigation links -->
    <a href="javascript:void(0);" class="iconphone" onclick="menuphone()">
      <i class="fa fa-bars"></i>
    </a>
  </div>


    
    <!-- Barre de haut de page -->
  <div class="topnav" id="myTopnav">
    <a href="./main.php" class="active gauchefloat">BDE CESI</a>
    <a href="http://ent.cesi.fr" class="gauchefloat">ENT Cesi</a>
    
    <?php
     if($_SESSION['role'] == 2){ ?>
    <a href="telechargerimage.php" class="gauchefloat">télécharger l'ensemble des images</a>
    <?php }
        if($_SESSION['role'] == 3){ ?>
          <a href="#about" class="gauchefloat" data-toggle="modal" data-target="#ajout">Ajouter un événement</a>
        
      <?php }
       if($_SESSION['role'] == 3){ ?>
        <a href="#about" class="gauchefloat" data-toggle="modal" data-target="#ajout2">Ajouter une activité</a>
      
        <?php }
       if($_SESSION['role'] == 3){ ?>
        <a href="#about" class="gauchefloat" data-toggle="modal" data-target="#ajout3">Ajouter un Article</a>

       <?php }

      if($_SESSION['adresse_mail'] == null){?>
      <p>
    <a href="#Inscription" data-toggle="modal" data-target="#exampleModal" class="droitefloat">Inscription</a>
    <a href="#connexion" data-toggle="modal" data-target="#conex" class="droitefloat">Connexion</a>
    
    
    <?php }
    else { ?> 
    <a href="deconnexion.php" class="droitefloat">Déconnexion</a>
    <a href="panier.php" class="droitefloat">Panier</a>
    <div class="droitefloat">
      <?php echo("Bienvenue "); echo($_SESSION['nom']); echo(" "); echo($_SESSION['prenom']); ?>
    </div>
    <?php } ?>   
  </div>

  <!-- The sidebar -->
  <div class="sidebar">
    <img src="./image/cesi-logo.png" alt="Logo cesi" />
    <a class="active" href="activite.php">Activités</a>
    <a href="evenementpasse.php">Evénements passés</a>
    <a href="http://localhost/Projetweb/boutique.php">Boutique</a>
    <a href="contact.php">Contact</a>
    <a href="https://www.facebook.com/bdecesirouen/" class="fa fa-facebook"></a>
    <a href="https://twitter.com/cesi_rouen" class="fa fa-twitter"></a>
    <a href="https://www.instagram.com/campus_cesi/?hl=fr" class="fa fa-instagram"></a>
    <a href="https://fr.linkedin.com/company/cesicampusrouen" class="fa fa-linkedin"></a>
  </div>
    
  <div class="modal fade" id="ajout" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Ajout Evenement :</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button> 
      </div>
      <form enctype="multipart/form-data" method="POST" action="formulaire.php">
      <div class="modal-body">

      <label for="pseudo">Pseudo :</label>
    <input type="text" name="pseudo" placeholder="Entrez votre pseudo"/> 
    <label for="titreArticle">Titre Evenement :</label>
    <input type="text" name="titreArticle" placeholder="Entrez le titre de l'article"/>
    <label for="contenuArticle">Contenue : </label>
    <input type="text" name="contenuArticle" placeholder="Entrez le contenu de votre acticle"/> 
    <label for="monfichier">Image de l'évenement :</label><br />
    <input type="file" name="monfichier"/><br />
      
      </div>
    
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <input type="submit" value="Ajouter" class="btn btn-primary"/>
      
      </div>
    </form>
    </div>
   </div>
   </div>

   <div class="modal fade" id="ajout2" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Ajout d'Activité :</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button> 
      </div>
      <form enctype="multipart/form-data" method="POST" action="formulaire2.php">
      <div class="modal-body">

      <label for="pseudo">Pseudo :</label>
    <input type="text" name="pseudo" placeholder="Entrez votre pseudo"/> 
    <label for="titreArticle">Titre Activité :</label>
    <input type="text" name="titreArticle" placeholder="Entrez le titre de l'article"/>
    <label for="contenuArticle">Contenue : </label>
    <input type="text" name="contenuArticle" placeholder="Entrez le contenu de votre acticle"/> 
    <label for="monfichier">Image de l'activité :</label><br />
    <input type="file" name="monfichier"/><br />
      
      </div>
    
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <input type="submit" value="Ajouter" class="btn btn-primary"/>
      
      </div>
    </form>
    </div>
   </div>
   </div>

   
   <div class="modal fade" id="boutique" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Recherche produit</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button> 
      </div>
      <form enctype="multipart/form-data" method="POST" action="boutique.php">
      <div class="modal-body">

      <label for="nom">Nom du produit :</label>
      <input type="text" name="nom" placeholder="Entrez le nom du produit"/> 
      <p class="categorylist">
			  <label for="local"><b>Categorie</b></label>
        <select type="select" id="categorie" name="categorie">
			  <option value="all">Tout les produits</option>
			  <option value="bonnet">Bonnet</option>
			  <option value="pull">Pull</option>
			  <option value="shirt">T-shirt</option>
        <option value="casquette">Casquette</option>
        <option value="voiture">Voiture</option>
        </select>		
        <br />	
		  </p>
      <label for="prixmin">Prix minimum : </label>
      <input type="text" name="min" placeholder="Entrez le prix minimum à afficher"/> 
      <label for="prixmax">Prix maximum :</label><br />
      <input type="text" name="max" placeholder="Entrez le prix maximum à afficher"/><br />
      
      </div>
    
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <input type="submit" value="Ajouter" class="btn btn-primary" />
      
      </div>
    </form>
    </div>
   </div>
   </div>

   <div class="modal fade" id="ajout3" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Ajout goodies :</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button> 
      </div>
      <form enctype="multipart/form-data" method="POST" action="formulaire3.php">
      <div class="modal-body">

      <label for="nom">Nom :</label>
    <input type="text" name="nom" placeholder="Entrez le nom du produit"/> 
    <label for="description">Description :</label>
    <input type="text" name="description" placeholder="Entrez la description du produit"/>
    <label for="categorie">Prix : </label>
    <input type="float" name="prix" placeholder="Entrez le prix du produit"/> 
    <br />
    <label for="categorie">Categories : </label>
    <select type="select" id="categorie" name="categorie">
    <option value="bonnet">Bonnet</option>
    <option value="pull">Pull</option>
    <option value="shirt">T-shirt</option>
    <option value="casquette">Casquette</option>
    <option value="voiture">Voiture</option>
    </select>
    <br />
    <br />
    <label for="monfichier">Photo : </label>
    <input type="file" name="monfichier" placeholder="Photo de l'article"/> 
      </div>
    
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <input type="submit" value="Ajouter" class="btn btn-primary"/>
      
      </div>
    </form>
    
    </div>
   </div>
   </div>


   <div class="modal fade" id="photo" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Ajouter une photo à l'évenement passé</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button> 
      </div>
      <form method="post" action="ajoutphoto.php" enctype="multipart/form-data">
      <div class="modal-body">
        
      <label for="mail">Votre photo :</label>
       <input type="file" name="file" id="file" />
       <br />
       <br />
      
      
      </div>
    
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <input type="submit" value="Ajouter" class="btn btn-primary"/>
      
      </div>
    </form>
    </div>
   </div>
   </div>

<div class="modal fade" id="com" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Ajouter une photo à l'évenement passé</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button> 
      </div>
      <form method="post" action="ajoutcom.php" enctype="multipart/form-data">
      <div class="modal-body">
        
      <label for="com">Votre Commentaire :</label>
       <input type="text" name="com" id="com" />
       <br />
       <br />  
      </div>   
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <input type="submit" value="Ajouter" class="btn btn-primary"/>     
      </div>
    </form>
    </div>
   </div>
   </div>

  <div class="modal fade" id="conex" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Connexion :</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button> 
      </div>
      <form method="post" action="interface.php" enctype="multipart/form-data">
      <div class="modal-body">
        
      <label for="mail">Votre mail :</label>
       <input type="email" name="mail" id="mail" />
       <br />
       <br />
       <label for="mdp">Votre mot de passe :</label>
       <input type="password" name="mdp" id="motDePasse" />
        <br /><br />
      
      </div>
    
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <input type="submit" value="Connexion" class="btn btn-primary"/>
      
      </div>
    </form>
    </div>
   </div>
   </div>

   <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Inscription :</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button> 
      </div>
      <form method="post" action="inscription.php" enctype="multipart/form-data">
      <div class="modal-body">
    <p>Completez ce formulaire pour créer un compte.</p>
    <hr>

    <label for="nom"><b>Nom</b></label>
    <input type="text" placeholder="Entrer votre nom" name="nom" required>

    <label for="prenom"><b>Prénom</b></label>
    <input type="text" placeholder="Entrer votre Prénom" name="prenom" required>

    <label for="mail"><b>Email</b></label>
    <input type="email" placeholder="Enter Email" name="mail" required>

    <label for="mdp"><b>Password</b></label>
    <input type="password" placeholder="Enter Password" name="mdp" pattern="^(?=.*\d)(?=.*[A-Z])(?=.*[a-z])([^\s]){7,15}$" title="Entre 8 et 16 charactère, au moins une majuscule et un nombre" required>

    <label for="repmdp"><b>Repeat Password</b></label>
    <input type="password" placeholder="Repeat Password" name="repmdp" required>

    <label for="local"><b>Localisation</b></label>
    <select type="select" id="country" name="local">
    <option value="aix">Aix</option>
    <option value="alger">Alger</option>
    <option value="arras">Arras</option>
    <option value="bordeaux">Bordeaux</option>
    <option value="rochelle">La Rochelle</option>
    <option value="lille">Lille</option>
    <option value="lyon">Lyon</option>
    <option value="nancy">Nancy</option>
    <option value="nanterre">Nanterre</option>
    <option value="nice">Nice</option>
    <option value="reims">Reims</option>
    <option value="rouen">Rouen</option>
    <option value="orlean">Orléan</option>
    <option value="pau">Pau</option>
    <option value="nazaire">Saint-Nazaire</option>
    <option value="strasbourg">Strasbourg</option>
    <option value="toulouse">Toulouse</option>
  </select>

      <br />
    <label for="remember">Remember me</label>
      <input type="checkbox" checked="checked" name="remember" style="margin-bottom:15px" value="oui"> 
    
    </div>
    <span> En s'inscrivant vous accepter les <a href="mentions.php"> Conditions d'utilisations </a> </span>
    
    <div class="modal-footer">
      <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      <input type="submit" value="Connexion" class="btn btn-primary"/>
    
    </div>

    

    </nav>


