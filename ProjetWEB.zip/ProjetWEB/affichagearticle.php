<?php
try {
  // On se connecte à MySQL
  $bdd = new PDO('mysql:host=localhost;dbname=projetweb;charset=utf8', 'root', '');
} catch (Exception $e) {
  // En cas d'erreur, on affiche un message et on arrête tout
  die('Erreur : ' . $e->getMessage());
}

if (empty($_POST['min'])) { //si le formulaire est vide /il n'y a pas de formulaire , on attribut un minimum par défault
  $min = 0;
} else {
  $min = $_POST['min'];
}
if (empty($_POST['max'])) { //si le formulaire est vide /il n'y a pas de formulaire , on attribut un minimum par défault
  $max = 9999999;
} else {
  $max = $_POST['max'];
}
if(empty($_POST['categorie'])){
  //procédure stockée pour sélectioner les articles et les afficher sans catégorie
$Article = $bdd->prepare('CALL `selectArticle`(:p2,:p3);');
$Article->bindValue(':p2', $min, PDO::PARAM_STR);
$Article->bindValue(':p3', $max, PDO::PARAM_STR);
$Article->execute();
}else{
  //procédure stockée pour sélectioner les articles et les afficher avec catégorie
$Article = $bdd->prepare('CALL `selectArticle2`(:p2,:p3,:p4);');
$Article->bindValue(':p2', $min, PDO::PARAM_STR);
$Article->bindValue(':p3', $max, PDO::PARAM_STR);
$Article->bindValue(':p4', $_POST['categorie'], PDO::PARAM_STR);
$Article->execute();
}


while ($art = $Article->fetch()) {
  // on affiche le résultat de la requête ligne par ligne
  ?><div class='card'>
    <?php if ($_SESSION['role'] == 3) { ?>
      <!-- si l'utilisateur est un membre du BDE on affiche un bouton pour supprimer l'article associé -->
      <a href="delArt.php" onclick="delArt(<?php echo ($art['id']) ?>)" class="buttonmois blacklinkbuttonimage">Supprimer cet Article </a>
    <?php } ?>
    <!--affichage de l'image de l'article -->
    <img src="./image/<?php echo ($art['url']); ?> " alt="AvatarArticle" class="photoArticle">

    <h1><?php echo ($art['nom']); ?></h1>
    <p> <?php echo ($art['description']); ?></p>
    <span class="time-right">Prix : <?php echo ($art['prix']); ?> €</span>
    <?php if ($_SESSION['role'] == 1) { ?>
      <!-- si l'utilisateur est étudiant on affiche un bouton pour ajouter l'article associé au panier-->
      <a href="" onclick="addpanier(<?php echo ($art['id']) ?>)" class="buttonmois blacklinkbuttonimage"> Ajouter cet Article à votre panier </a>
    <?php } ?>
  </div>
  <br /><br />
<?php  }
$Article->closeCursor();
