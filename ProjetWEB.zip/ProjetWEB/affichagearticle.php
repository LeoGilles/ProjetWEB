<?php

try
{
	// On se connecte à MySQL
	$bdd = new PDO('mysql:host=localhost;dbname=projetweb;charset=utf8', 'root', '');
}
catch(Exception $e)
{
	// En cas d'erreur, on affiche un message et on arrête tout
        die('Erreur : '.$e->getMessage());
}





  $Article = $bdd->prepare('CALL `selectArticle`(:p0);');
  $Article->bindValue(':p0', $idphotos , PDO::PARAM_STR); 
  $Article->execute(); 

   while($Article = $photos->fetch()){       ?>
<?php if($_SESSION['role'] == 3){ ?>
  <a href="delcom.php"><button onclick="delArt(<?php echo ($Article['id'])?>)" class="buttonmois blacklinkbuttonimage" >Supprimer ce commentaire  <?php echo ($photosres['idcom'])?> </button></a>   
<?php } ?>

  <img src="./image/<?php echo($Article['url']);?> " alt="AvatarArticle">
  <h1><?php echo($Article['nom']);?></h1>
  <p> <?php echo($Article['description']);?></p>
  <span class="time-right">Prix : <?php echo($Article['Prix']);?> </span>

<?php  } $Article->closeCursor(); ?>

