<?php
try
{
	// On se connecte à MySQL
	$bdd = new PDO('mysql:host=localhost;dbname=projetweb;charset=utf8', 'root', '');
}
catch(Exception $e)
{
	// En cas d'erreur, on affiche un message et on arrête tout
        die('Erreur : '.$e->getMessage());
}

if(empty($_POST['min'])){
  $mine = 0 ;
}
if(empty($_POST['max'])){
  $maxe = 9999999 ;
}

  $Article = $bdd->prepare('CALL `selectArticle`(:p2,:p3);');
  $Article->bindValue(':p2', $mine , PDO::PARAM_STR); 
  $Article->bindValue(':p3', $maxe , PDO::PARAM_STR);
  $Article->execute(); 

   while($art = $Article->fetch()){
            ?><div class='card'>
<?php if($_SESSION['role'] == 3){ ?>
  
  <a href="delArt.php" onclick="delArt(<?php echo ($art['id'])?>)" class="buttonmois blacklinkbuttonimage" >Supprimer cet Article </a>   
<?php } ?>

  <img src="./image/<?php echo($art['url']);?> " alt="AvatarArticle" class="photoArticle">

  <h1><?php echo($art['nom']);?></h1>
  <p> <?php echo($art['description']);?></p>
  <span class="time-right">Prix : <?php echo($art['prix']);?> €</span>
  <?php if($_SESSION['role'] == 3){ ?>
  
  <a href="" onclick="addpanier(<?php echo ($art['id'])?>)" class="buttonmois blacklinkbuttonimage" > Ajouter cet Article à votre panier </a>   
<?php } ?>
</div>
<br /><br />
<?php  } $Article->closeCursor();  

