<?php 
session_start();
try
{
	// On se connecte à MySQL
	$bdd = new PDO('mysql:host=localhost;dbname=projetweb;charset=utf8', 'root', '');
}
catch(Exception $e)
{
	// En cas d'erreur, on affiche un message et on arrête tout
        die('Erreur : '.$e->getMessage());
}
$max = $bdd->prepare('CALL `maxevenement`;');
$max->execute();
$idmax = $max->fetch();
 $max->closeCursor();
$raque = $bdd->prepare('CALL `allevenement`;');
$raque->execute();

    while($donnes = $raque->fetch()){

        if($donnes['id'] != $idmax['id']){  
            if($_SESSION['role'] == 3)
            { ?> 
              <a href="download.php"><button class="buttonimage" onclick="down( <?php echo ($donnes['id'])?>)">Telecharger la liste des Inscrits pour cette activité</button></a> <?php
            } ?>
         <div class='card'>
         <img src='image/<?php echo ($donnes['photo']); ?>' alt='leophoto' class='photoArticle'>
         <h1><?php echo ($donnes['titre']); ?></h1>
         <p class='price'>Créée par <?php echo ($donnes['pseudo']); ?> le  <?php echo ($donnes['date_creation']); ?></p>
         <p><?php echo ($donnes['contenu']); ?></p>
         <?php if($_SESSION['role'] != null ){   ?>
            
    <div class="dropdown">

      <button onclick="myDrop(<?php echo ($donnes['id'])?>)" class="buttonmois">Voir les photos </button>
      <div id="Dropdown<?php echo ($donnes['id'])?>" class="dropdown-content">                
        <?php include("affichageimage.php"); ?>
  
      </div>
    </div>

    <?php    }if($_SESSION['role'] == null){ ?>
    <a><button class="buttonmois">Connectez vous pour voir les photos</button></a>
    <?php } ?>

     </div>
     <br /><br />
    <?php  } } $raque->closeCursor(); ?>

    <script type='text/JavaScript'> 

			function down(nav){
                $.ajax({
		    type: "POST",
		    url: './download.php',
			data:"m=" + nav ,
		    success:
		    function(retour){
		        
		    }}); 
            }

      function delcom(nav){
                $.ajax({
		    type: "POST",
		    url: './delcom.php',
			data:"m=" + nav ,
		    success:
		    function(retour){
          alert(retour);
		      
		    }}); 
            } 

      function delimg(nav){
                $.ajax({
		    type: "POST",
		    url: './delimg.php',
			data:"m=" + nav ,
		    success:
		    function(retour){
		        
		    }}); 
            }             
        
/* When the user clicks on the button, 
toggle between hiding and showing the dropdown content */
function myDrop(x) {
  document.getElementById("Dropdown"+x).classList.toggle("show");
}

// Close the dropdown menu if the user clicks outside of it
window.onclick = function(event) {
  if (!event.target.matches('.dropbtn')) {
    var dropdowns = document.getElementsByClassName("dropdown-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
      }
    }
  }
}

function photo(nav){
                $.ajax({
		    type: "POST",
		    url: './ajoutphoto.php',
			data:"m=" + nav ,
		    success:
		    function(retour){
		        
		    }}); 
            }
            
function com(nav){
                $.ajax({
		    type: "POST",
		    url: './ajoutcom.php',
			data:"m=" + nav ,
		    success:
		    function(retour){
		        
		    }}); 
            }

function like(nav){
                $.ajax({
		    type: "POST",
		    url: './like.php',
			data:"m=" + nav ,
		    success:
		    function(retour){
		       
		    }}); 
            }

// Get the modal
var modal = document.getElementById("myModal");

// Get the button that opens the modal
var btn = document.getElementById("myBtn");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// When the user clicks on the button, open the modal 
btn.onclick = function() {
  modal.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
  modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
}

            
          

</script>