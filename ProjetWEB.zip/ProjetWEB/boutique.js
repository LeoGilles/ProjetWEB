$(function(){  // Fonction permettant de vérifier si le doc est bien chargé
    setInterval(function(){ //permet de définir une action qui va se répéter à intervalle régulier.
        $(".slideshow ul").animate({marginLeft:-600},800,function(){ //cibler notre ul que nous allons faire bouger vers la gauche grâce à une animation qui va appliquer une marge négative de 350px en 0,8 secondes
            $(this).css({marginLeft:0}).find("li:last").after($(this).find("li:first"));
        })
    }, 2000);
});

//La fonction animate() permet d’exécuter une fonction de callback, il s’agit d’une fonction exécutée lorsque animate() retourne « complete »
//Cette fonction de callback, nous la déclarons juste après le paramètre de durée de l’animation.
//  $(this) = représente chaque .slideshow ul
/* élément ul auquel nous supprimons la marge négative
récemment attribuée par l’animation, puis nous allons chercher
le dernier li de notre liste (find("li:last")) et nous y plaçons
 juste après (after()) le premier élément de notre
 liste ($(this).find("li:first")). */
