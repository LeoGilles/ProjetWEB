
<?php
session_start(); // on démarre la session

$nav = 1;
if ((isset($_POST['m']))) {
	$_SESSION['insc']['idcom'] = $_POST['m']; //résultat de la requte ajax
	echo "suppression du commentaire !";
} else {
	try {
		// On se connecte à MySQL
		$bdd = new PDO('mysql:host=localhost;dbname=projetweb;charset=utf8', 'root', '');
	} catch (Exception $e) {
		// En cas d'erreur, on affiche un message et on arrête tout
		die('Erreur : ' . $e->getMessage());
	}
	$membre = $_SESSION['id'];
	$idevent = $_SESSION['insc']['idcom'];

	if ($_SESSION['id'] != null) {
		//procédure stockée pour supprimer un commentaire
		$insc = $bdd->prepare('CALL `delcom`(:p2);');
		$insc->bindValue(':p2', $idevent, PDO::PARAM_STR);
		$insc->execute();
		$donne = $insc->fetch();
		$insc->closeCursor();
		header('Location: ./evenementpasse.php');
	} else {
		echo ("error desinscription");
	}
}
?>
 