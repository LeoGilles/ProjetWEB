
<?php
session_start();

$nav=1;
if ( (isset($_POST['m']) )  ){ 
$_SESSION['download'] = $_POST['m'];
echo "Vous allez etre redirigé";

}
else{
    try
{
	// On se connecte à MySQL
	$bdd = new PDO('mysql:host=localhost;dbname=projetweb;charset=utf8', 'root', '');
}
catch(Exception $e)
{
	// En cas d'erreur, on affiche un message et on arrête tout
        die('Erreur : '.$e->getMessage());
}

 $idevent = $_SESSION['download'];



 $liste = $bdd->prepare('CALL `listeinscrit`(:p3);');
 $liste->bindValue(':p3', $idevent , PDO::PARAM_STR);
  $liste->execute();  
  ob_start();
  ?> <h1>Listes des inscrits : </h1> <?php
  while($donnes = $liste->fetch()){ ?>
    <div class='card'> 
        <p>"<?php echo($donnes['nom']); ?> <?php echo($donnes['prenom']); ?>" est inscrit dans l'évenement "<?php echo($donnes['titre']); ?>"</p>
    </div><?php
  }
  $liste->closecursor();  
  $content = ob_get_clean();
   echo("yolo");
  require('vendors/html2pdf/html2pdf.class.php');
  try{
   
    $pdf = new HTML2PDF('p','A4','fr');
    $pdf->writeHTML($content);
    $pdf->Output('test.pdf');
  }catch(HTML2PDF_exception $e){
      die($e);
  }

}
?>
 