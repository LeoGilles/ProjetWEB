
<?php
session_start();

$nav=1;
if ( (isset($_POST['m']) )  ){
$_SESSION['download'] = $_POST['m'];
echo "Vous allez etre redirigé";

}
else{

    $idevent = $_SESSION['download'];
try
{
// On se connecte à MySQL
$bdd = new PDO('mysql:host=localhost;dbname=projetweb;charset=utf8', 'root', '');
}
catch(Exception $e)
{
// En cas d'erreur, on affiche un message et on arrête tout
    die('Erreur : '.$e->getMessage());
}
$liste = $bdd->prepare('CALL `listeinscrit`(:p3);');
$liste->bindValue(':p3', $idevent , PDO::PARAM_STR);
$liste->execute();
$donnee = $liste->fetchAll(PDO::FETCH_ASSOC);
$liste->closeCursor();
// Création de la ligne d'en-tête
$entete = array("Nom", "Prenom", "Evenement");
$separateur = ";";

// Affichage de la ligne de titre, terminée par un retour chariot
echo implode($separateur, $entete)."\r\n";

// Affichage du contenu du tableau
foreach ($donnee as $data) {
echo $data['nom'].";";
echo $data['prenom'].";";
echo $data['titre'].";\n";
}

header("Content-Type: text/csv; charset=UTF-8");
header("Content-Type: text/csv");
header("Content-disposition: filename=mon-tableau.csv");

} ?>