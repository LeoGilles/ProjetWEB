<meta charset="utf-8" />
  <?php
  // Connexion à la base de données
  try
  {
  	$bdd = new PDO('mysql:host=localhost;dbname=projetweb;charset=utf8', 'root', '');
  }
  catch(Exception $e)
  {
          die('Erreur : '.$e->getMessage());
  }

date_default_timezone_set('Europe/Paris');
$dateTime = date("Y-m-d H:i:s");
            if(isset($_POST['nom'],$_POST['description'],$_POST['prix'],$_POST['categorie']) AND !empty($_POST['nom'])  AND !empty($_POST['description'])  AND !empty($_POST['prix']) AND !empty($_POST['categorie']))
            {
               
              $nom = htmlspecialchars($_POST['nom']);

              $description = htmlspecialchars($_POST['description']);

              $prix = htmlspecialchars($_POST['prix']);

              $categorie = htmlspecialchars($_POST['categorie']);

              $addPhoto = $_FILES['monfichier']['name'];

              $insertionTable = $bdd->prepare('CALL `addproduit`(:p0,:p1,:p2,:p3,:p4);');

              $insertionTable->bindValue(':p0', $nom , PDO::PARAM_STR);
              $insertionTable->bindValue(':p1', $description , PDO::PARAM_STR);
              $insertionTable->bindValue(':p2', $prix , PDO::PARAM_STR);
              $insertionTable->bindValue(':p3', $categorie , PDO::PARAM_STR);
              $insertionTable->bindValue(':p4', $addPhoto , PDO::PARAM_STR);
              $insertionTable->execute();
              $insertionTable->closeCursor();
              move_uploaded_file($_FILES['monfichier']['tmp_name'], 'image/' . basename($_FILES['monfichier']['name']));
            }else {
              $formError = "Un des champs est vide";
            }
            header('Location: ./main.php');