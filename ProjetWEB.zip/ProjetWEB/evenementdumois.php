<?php 
session_start();
try
{
	// On se connecte à MySQL
	$bdd = new PDO('mysql:host=localhost;dbname=projetweb;charset=utf8', 'root', '');
}
catch(Exception $e)
{
	// En cas d'erreur, on affiche un message et on arrête tout
        die('Erreur : '.$e->getMessage());
}
$max = $bdd->prepare('CALL `maxevenement`;');
$max->execute();
$idmax = $max->fetch();
 $max->closeCursor();
$raque = $bdd->prepare('CALL `allevenement`;');
$raque->execute();

$membre = $_SESSION['id'];

    while($donnes = $raque->fetch()){

        $idevent = $donnes['id'];

        $insc = $bdd->prepare('CALL `selectevent`(:p2,:p3);');
        $insc->bindValue(':p2', $membre , PDO::PARAM_STR); 
        $insc->bindValue(':p3', $idevent , PDO::PARAM_STR); 
        $insc->execute();
        $donne = $insc->fetch();
        $insc->closeCursor();

        if($donnes['id'] == $idmax['id']){  
        ?> 
        <h1 style="text-align: center;">Evenement du Mois :</h1>
        <br /><br />
		<h2 class="titremois"><?php echo ($donnes['titre']); ?></h2>
         <img src='image/<?php echo ($donnes['photo']); ?>' alt='leophoto' class='photoArticle' >
         <br /><br />
         <p class="datemois"> Créer par <?php echo ($donnes['pseudo']); ?> le  <?php echo ($donnes['date_creation']); ?> </p>
         <p class="contenumois"><?php echo ($donnes['contenu']); ?></p>
         <?php if($_SESSION['role'] == 1 || $_SESSION['role'] == 3){   if($_SESSION['id'] != $donne['id_membre']){  ?>

            <a href="inscevent.php" ><button class="buttonmois" onclick="go( <?php echo ($donnes['id'])?>)" >S'inscrire </button></a>
        
            <?php } }if($_SESSION['role'] == 2 ){ ?>
<a><button class="buttonmois">Vous n'etez pas étudiants</button></a>
<?php } if($_SESSION['role'] == null){ ?>
    <a><button class="buttonmois">Connecter vous pour vous inscrire</button></a>

     <?php  }if($_SESSION['id'] == $donne['id_membre']){ 
         if($_SESSION['role'] != null){?>
    <a href="desevent.php"><button class="buttonmois" onclick="ungo( <?php echo ($donnes['id'])?>)">Se désinscrire</button></a>
    <?php  } }?>
    
     </div>
     <br /><br /> <?php
        }
     }
         $raque->closeCursor();

         ?>

<script type='text/JavaScript'>  
			function go(nav){
                $.ajax({
		    type: "POST",
		    url: './inscevent.php',
			data:"m=" + nav ,
		    success:
		    function(retour){
		        alert(retour );
		    }}); 
            }
          </script>
         <script type='text/JavaScript'>  
			function ungo(nav){
                $.ajax({
		    type: "POST",
		    url: './desactivite.php',
			data:"m=" + nav ,
		    success:
		    function(retour){
		        alert(retour );
		    }}); 
            }
          </script>