
<?php
session_start();

$nav=1;
if ( (isset($_POST['m']) )  ){ 
$_SESSION['insc']['idArt'] = $_POST['m'];
echo "suppression de l'article !";

}
else{
    try
{
	// On se connecte à MySQL
	$bdd = new PDO('mysql:host=localhost;dbname=projetweb;charset=utf8', 'root', '');
}
catch(Exception $e)
{
	// En cas d'erreur, on affiche un message et on arrête tout
        die('Erreur : '.$e->getMessage());
}
 $membre = $_SESSION['id'];
 $idArt = $_SESSION['insc']['idArt'];
 
if($_SESSION['id'] != null){
 $insc = $bdd->prepare('CALL `delArt`(:p2);');
 $insc->bindValue(':p2', $idArt , PDO::PARAM_STR);  
 $insc->execute();
 $donne = $insc->fetch();
 $insc->closeCursor();
header('Location: ./boutique.php');
}else{
	echo("error desinscription");
}
 
}
?>
 