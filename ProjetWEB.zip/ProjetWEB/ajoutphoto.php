<?php
session_start();

$nav=0;
if ( (isset($_POST['m']) )  ){ 
$_SESSION['insc']['id'] = $_POST['m'];
echo "Completer le formulaire .";

}
else{
$event = $_SESSION['insc']['id'];    
$filename = $_FILES['file']['name'];
try
{
	// On se connecte à MySQL
	$bdd = new PDO('mysql:host=localhost;dbname=projetweb;charset=utf8', 'root', '');
}
catch(Exception $e)
{
	// En cas d'erreur, on affiche un message et on arrête tout
        die('Erreur : '.$e->getMessage());
}
if($_SESSION['role'] == 1){
    $insc = $bdd->prepare('CALL `addphoto`(:p2,:p3);');
    $insc->bindValue(':p2', $event , PDO::PARAM_STR); 
    $insc->bindValue(':p3', $filename , PDO::PARAM_STR); 
    $insc->execute();
    $donne = $insc->fetch();
    $insc->closeCursor();
    move_uploaded_file($_FILES['file']['tmp_name'], 'image/' . basename($_FILES['file']['name']));
    header('Location: ./evenementpasse.php');
   }else{
       echo("error utilisateur");
   }

}
?>