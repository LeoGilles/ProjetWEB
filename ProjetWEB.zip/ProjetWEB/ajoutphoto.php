<?php
session_start(); //On démarre la session

$nav = 0;
if ((isset($_POST['m']))) {
    $_SESSION['insc']['id'] = $_POST['m']; //   résultat de la fonction ajax
    echo "Completer le formulaire .";
} else { //reste de la page qui est appelé par le href une fois la fonction ajax terminé
    $event = $_SESSION['insc']['id'];
    $filename = $_FILES['file']['name'];
    try {
        // On se connecte à MySQL
        $bdd = new PDO('mysql:host=localhost;dbname=projetweb;charset=utf8', 'root', '');
    } catch (Exception $e) {
        // En cas d'erreur, on affiche un message et on arrête tout
        die('Erreur : ' . $e->getMessage());
    }
    if ($_SESSION['role'] == 1) {
        // appelle de la procédure stockée pour ajouter l'url d'une image à la BDD
        $insc = $bdd->prepare('CALL `addphoto`(:p2,:p3);');
        $insc->bindValue(':p2', $event, PDO::PARAM_STR);
        $insc->bindValue(':p3', $filename, PDO::PARAM_STR);
        $insc->execute();
        $donne = $insc->fetch();
        $insc->closeCursor();
        //on déplace le fichier uploadé dans un dossier qui contient toute les images du site
        move_uploaded_file($_FILES['file']['tmp_name'], 'image/' . basename($_FILES['file']['name']));
        header('Location: ./evenementpasse.php'); //redirection
    } else {
        echo ("error utilisateur");
    }
}
