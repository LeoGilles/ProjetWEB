
<?php
session_start();

$nav=0;
if ( (isset($_POST['m']) )  ){ 
$_SESSION['insc']['like'] = $_POST['m'];

 try
    {
        // On se connecte à MySQL
        $bdd = new PDO('mysql:host=localhost;dbname=projetweb;charset=utf8', 'root', '');
    }
    catch(Exception $e)
    {
        // En cas d'erreur, on affiche un message et on arrête tout
            die('Erreur : '.$e->getMessage());
    }
    $membre = $_SESSION['id'];
    $idphoto = $_SESSION['insc']['like'];



    $conf = $bdd->prepare('CALL `conflike`(:p2,:p3);');
    $conf->bindValue(':p2', $membre , PDO::PARAM_STR); 
    $conf->bindValue(':p3', $idphoto , PDO::PARAM_STR); 
    $conf->execute();
    $conflike = $conf->fetch();
    $conf->closeCursor();
    

    if($conflike['id_photo'] != $idphoto){

        $confirm = $bdd->prepare('CALL `Addlike`(:p3);');
        $confirm->bindValue(':p3', $idphoto , PDO::PARAM_STR); 
        $confirm->execute();
        $donnes = $confirm->fetch();
        $confirm->closeCursor();

        $confirmadd = $bdd->prepare('CALL `likeconfirmadd`(:p2,:p3);');
        $confirmadd->bindValue(':p2', $membre , PDO::PARAM_STR); 
        $confirmadd->bindValue(':p3', $idphoto , PDO::PARAM_STR); 
        $confirmadd->execute();
        $donnes = $confirmadd->fetch();
        $confirmadd->closeCursor();

        
    }
    else{

        $insc = $bdd->prepare('CALL `remlike`(:p2);');
        $insc->bindValue(':p2', $idphoto , PDO::PARAM_STR); 
        $insc->execute();
        $donne = $insc->fetch();
        $insc->closeCursor();

        $confirmrem = $bdd->prepare('CALL `likeconfirmrem`(:p2,:p3);');
        $confirmrem->bindValue(':p2', $membre , PDO::PARAM_STR); 
        $confirmrem->bindValue(':p3', $idphoto , PDO::PARAM_STR); 
        $confirmrem->execute();
        $donnes = $confirmrem->fetch();
        $confirmrem->closeCursor();

        
    }
}
else{
   
header('Location: ./evenementpasse.php');
} 