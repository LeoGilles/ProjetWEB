<?php

try {
	// On se connecte à MySQL
	$bdd = new PDO('mysql:host=localhost;dbname=projetweb;charset=utf8', 'root', '');
} catch (Exception $e) {
	// En cas d'erreur, on affiche un message et on arrête tout
	die('Erreur : ' . $e->getMessage());
}
//procédure stockée pour récuperer les coordonées des membres du BDE
$requete = $bdd->prepare('CALL `mailbde`;');
$requete->execute();


?>
<!-- envoie de mail /notification aux membres du BDE par un salarié -->
<a href="mailto:<?php while ($mailbde = $requete->fetch()) {
					echo ($mailbde['adresse_mail'] . ', ');
				} ?>"> Envoyer un mail pour un problème </a>

<?php
$requete->closeCursor();
?>