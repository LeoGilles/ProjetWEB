
<?php
session_start();

$nav=0;
if ( (isset($_POST['m']) )  ){ 
$_SESSION['insc']['id'] = $_POST['m'];
echo "Vous êtes désormais inscrit a cet évenement !";

}
else{
    try
{
	// On se connecte à MySQL
	$bdd = new PDO('mysql:host=localhost;dbname=projetweb;charset=utf8', 'root', '');
}
catch(Exception $e)
{
	// En cas d'erreur, on affiche un message et on arrête tout
        die('Erreur : '.$e->getMessage());
}
 $membre = $_SESSION['id'];
 $idevent = $_SESSION['insc']['id'];

if($_SESSION['id'] != null){
 $insc = $bdd->prepare('CALL `inscevent`(:p2,:p3);');
 $insc->bindValue(':p2', $membre , PDO::PARAM_STR); 
 $insc->bindValue(':p3', $idevent , PDO::PARAM_STR); 
 $insc->execute();
 $donne = $insc->fetch();
 $insc->closeCursor();
 header('Location: ./main.php');
}else{
	echo("error inscription");
}
 
}
?>
 