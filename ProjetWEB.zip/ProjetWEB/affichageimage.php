<?php 
session_start();
try
{
	// On se connecte à MySQL
	$bdd = new PDO('mysql:host=localhost;dbname=projetweb;charset=utf8', 'root', '');
}
catch(Exception $e)
{
	// En cas d'erreur, on affiche un message et on arrête tout
        die('Erreur : '.$e->getMessage());
}

if($_SESSION['role'] == 1 ){           ?>
    <a href="#about" data-toggle="modal" data-target="#photo" onclick="photo(<?php echo ($donnes['id'])?>)"><button class="buttonmois orangelinkbuttonimage" >Ajouter une photo</button></a>  
  <?php } 
  $idevent = $donnes['id'];
$phot = $bdd->prepare('CALL `selectphoto`(:p2);');
$phot->bindValue(':p2', $idevent , PDO::PARAM_STR); 
$phot->execute();

  while($donn = $phot->fetch()){    
     if($_SESSION['role'] == 1 ){ ?>
     <br />
    <a href="#about" data-toggle="modal" data-target="#com" onclick="com(<?php echo ($donn['id'])?>)"><button class="buttonmois blacklinkbuttonimage" >Ajouter un commentaire</button></a> 
    <?php }  
     if($_SESSION['role'] == 3 ){ ?>
     <br /><br />
      <a href="delimg.php" onclick="delimg(<?php echo ($donn['id'])?>)" class="buttondelimg orangelinkbuttonimage" >Supprimer cette image </a>   
      <?php } ?>
<a href="#about" id="myBtn"><img src='image/<?php echo ($donn['url']); ?>' alt='leophoto' style="text-align:center;" width="100%" height="70%"></a>
 <?php if($_SESSION['role'] == 1 ){           ?>
  
       <a href="evenementpasse.php" onclick="like(<?php echo ($donn['id'])?>)" class="buttondelimg redlinkbuttonimage" > ♥ <?php echo ($donn['nbr_like']); ?></a>
        <?php }
      include("affichagecommentaire.php"); 

   } $phot->closeCursor();  ?>